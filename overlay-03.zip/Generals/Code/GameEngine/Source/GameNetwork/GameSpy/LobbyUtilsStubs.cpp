// GeneralsX Android port: base Generals build.
// Core/LobbyUtils.cpp is written for GeneralsOnline (Zero Hour only) and is excluded from the
// base-game build. These no-op stand-ins satisfy the references the base game's old GameSpy
// lobby/profile screens still make. Online lobbies are not supported in the base-game port.

#include "PreRTS.h"	// This must go first in EVERY cpp file in the GameEngine

#include <cstdint>
#include "Common/AsciiString.h"
#include "Common/NameKeyGenerator.h"

class GameWindow;

GameWindow *GetGameListBox() { return nullptr; }
GameWindow *GetGameInfoListBox() { return nullptr; }
NameKeyType GetGameListBoxID() { return NAMEKEY_INVALID; }
void GrabWindowInfo() {}
void ReleaseWindowInfo() {}
void RefreshGameInfoListBox( GameWindow *, GameWindow * ) {}
void RefreshGameListBoxes() {}
void ToggleGameListType() {}
Bool HandleSortButton( NameKeyType ) { return FALSE; }

// Core headers declare the 64-bit-id overload; the base game defines the 32-bit one
// (PopupPlayerInfo.cpp). Forward the 64-bit call to it.
void SetLookAtPlayer( Int id, AsciiString nick );
void SetLookAtPlayer( int64_t id, AsciiString nick ) { SetLookAtPlayer( (Int)id, nick ); }
